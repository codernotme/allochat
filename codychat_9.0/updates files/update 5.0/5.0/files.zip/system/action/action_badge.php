<?php
require('../config_session.php');
session_write_close();

if(!useBadge()){
	die();
}

function badgeDataDetails(){
	global $mysqli, $setting, $data;
	
	$get_info = $mysqli->query("
		SELECT
		(SELECT count(id) FROM boom_pro_like WHERE target = '{$data['user_id']}') as likes,
		(SELECT SUM(gift_count) FROM boom_users_gift WHERE target = '{$data['user_id']}') as gifts,
		(SELECT COUNT(*) FROM boom_friends WHERE target = '{$data['user_id']}' AND fstatus = 3) as friends
	");
	$info = $get_info->fetch_assoc();
	$res['like'] = floor($info['likes'] / $setting['balike']);
	$res['gift'] = floor($info['gifts'] / $setting['bagift']);
	$res['friend'] = floor($info['friends'] / $setting['bafriend']);
	$res['beat'] = floor($data['user_beat'] / $setting['babeat']);
	$res['gold'] = floor($data['user_sgold'] / $setting['bagold']);
	$res['chat'] = floor($data['user_level'] / $setting['bachat']);
	$res['member'] = getYears($data['user_join']);
	$res['auth'] = $data['user_auth'];
	$res['top'] = $data['badge_top'] + $data['badge_qtop'];
	
	if($data['badge_qtop'] > 0){
		$mysqli->query("UPDATE boom_users_data SET badge_qtop = 0 WHERE uid = '{$data['user_id']}'");
	}
	
	return $res;
}

$data = joinProfileDetails($data);
$badge = badgeDataDetails();
$r = [];
$r['modal'] = [];

if($badge['member'] > $data['badge_member']){
	$mod = buildBadge('badge_member', $badge['member']);
	array_push($r['modal'], $mod);
}
if($badge['auth'] > $data['badge_auth']){
	$mod = buildBadge('badge_auth', $badge['auth']);
	array_push($r['modal'], $mod);
}

if($badge['chat'] > $data['badge_chat'] && useLevel()){
	$mod = buildBadgeLevel('badge_chat', $badge['chat']);
	array_push($r['modal'], $mod);
}

if($badge['gold'] > $data['badge_gold'] && useGold()){
	$mod = buildBadgeLevel('badge_gold', $badge['gold']);
	array_push($r['modal'], $mod);
}

if($badge['beat'] > $data['badge_beat']){
	$mod = buildBadgeLevel('badge_beat', $badge['beat']);
	array_push($r['modal'], $mod);
}

if($badge['like'] > $data['badge_like'] && useLike()){
	$mod = buildBadgeLevel('badge_like', $badge['like']);
	array_push($r['modal'], $mod);
}

if($badge['friend'] > $data['badge_friend']){
	$mod = buildBadgeLevel('badge_friend', $badge['friend']);
	array_push($r['modal'], $mod);
}

if($badge['gift'] > $data['badge_gift'] && useGift()){
	$mod = buildBadgeLevel('badge_gift', $badge['gift']);
	array_push($r['modal'], $mod);
}

if($badge['top'] > $data['badge_top'] && useLevel()){
	$mod = buildBadgeLevel('badge_top', $badge['top']);
	array_push($r['modal'], $mod);
}

$mysqli->query("
	UPDATE boom_users_data 
	SET 
	badge_auth = '{$badge['auth']}', badge_member = '{$badge['member']}', badge_chat = '{$badge['chat']}', badge_top = '{$badge['top']}', badge_gold = '{$badge['gold']}',
	badge_beat = '{$badge['beat']}', badge_like = '{$badge['like']}', badge_friend = '{$badge['friend']}', badge_gift = '{$badge['gift']}'
	WHERE uid = '{$data['user_id']}'
");

echo json_encode($r, JSON_UNESCAPED_UNICODE);
?>