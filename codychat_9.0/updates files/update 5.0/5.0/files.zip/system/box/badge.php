<div class="vpad15">
	<div class="modal_content">
		<div class="centered_element bpad10">
			<img class="large_icon brelative" src="<?php echo $boom['icon']; ?>"/>
		</div>
		<div class="centered_element hpad20">
			<p class="text_large bold tpad10"><?php echo $boom['title']; ?></p>
			<p class="text_small tpad10"><?php echo $boom['text']; ?></p>
		</div>
	</div>
	<div class="modal_control">
		<div class="tpad10 centered_element">
			<button class="close_modal ok_btn reg_button"><?php echo $lang['ok']; ?></button>
		</div>
	</div>
</div>