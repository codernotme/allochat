<?php
require('../../config_session.php');
require('../../function_leaderboard.php');

if(!useGift()){ 
	die();
}
?>
<div id="xp_leader_menu" class="bpad10">
	<div class="reg_menu">
		<ul>
			<li class="reg_menu_item rselected" data="gift_lead" data-z="gifttotal"><?php echo $lang['total']; ?></li>
			<li class="reg_menu_item" data="gift_lead" data-z="giftvalue"><?php echo $lang['value']; ?></li>
		</ul>
	</div>
</div>
<div id="gift_lead" class="vpad15">
	<div class="reg_zone" id="gifttotal"><?php echo getGiftLeader('count'); ?></div>
	<div class="reg_zone hide_zone" id="giftvalue"><?php echo getGiftLeader('value'); ?></div>
</div>