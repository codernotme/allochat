<?php
require('../../config_session.php');
require('../../function_leaderboard.php');

if(!useLike()){ 
	die();
}
?>
<div id="like_leaderboard_content">
	<?php echo getLikeLeader(); ?>
</div>