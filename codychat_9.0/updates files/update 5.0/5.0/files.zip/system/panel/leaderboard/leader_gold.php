<?php
require('../../config_session.php');
require('../../function_leaderboard.php');

if(!useGold()){ 
	die();
}
?>
<div id="gold_leaderboard_content">
	<?php echo getGoldLeader('user_gold'); ?>
</div>