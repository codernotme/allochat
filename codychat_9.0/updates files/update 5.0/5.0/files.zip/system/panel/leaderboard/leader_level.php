<?php
require('../../config_session.php');
require('../../function_leaderboard.php');

if(!useLevel()){ 
	die();
}
?>
<div id="level_leaderboard_content">
<?php echo getLevelLeader(); ?>
</div>